import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class TaskService {

  constructor( private _http: HttpClient) {

  }

  getAll(){
  	console.log('IM HERE');
  	this._http.get('/tasks')
  	.subscribe(data => console.log('All our tasks', data));
  }

}
