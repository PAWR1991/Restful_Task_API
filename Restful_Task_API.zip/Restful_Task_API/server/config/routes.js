let mongoose = require("mongoose");
let TaskController = require('../controllers/TaskController.js');

module.exports = function(app){
	app.get('/tasks', TaskController.all);
	app.get('/tasks/:id', TaskController.byId);
	app.post('/tasks', TaskController.create);
	app.put('/tasks/:id', TaskController.update);
	app.delete('/tasks/:id', TaskController.delete);
}