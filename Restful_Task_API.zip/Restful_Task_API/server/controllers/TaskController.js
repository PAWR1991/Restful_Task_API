let mongoose = require('mongoose');
let Task = mongoose.model('Task');
const bodyParser = require('body-parser');

class TaskController{
	all(req,res){
		console.log('all');
		Task.find({}, (err,task)=>{
			console.log("attempting to find");
			if(err){
				console.log('Yev sucks at coding and should give up');
			}
			else {
				console.log(task);
				res.json(task);
			}
		});
	}

	byId(req,res){
		console.log('byId');
		Task.find({_id:req.params.id}, (err,task)=>{
			if(err){
				console.log('Eirika needs to paid attention');
			}
			else{
				console.log(task);
				res.json(task[0]);
			}
		});
	}

	create(req,res){
		console.log('create');
		console.log(req.body);
		let task = new Task(req.body);
		task.save((err)=>{
			if(err){
				console.log(err);
			}else {
				console.log('WE SAVE A THING');
				res.json(task);
			}
		});
	}

	update(req,res){
		console.log('update');
		Task.update({_id:req.params.id}, (req.body), (err, is_this_defined)=>{
			if(err){
				console.log('Paul hates this');
			}
			else{
				console.log(is_this_defined);
				console.log(req.body);
				res.json(is_this_defined);
				console.log('WE UPDATED A TING');
			}
		});
	}
	delete(req,res){
		console.log('delete');
		Task.remove({_id:req.params.id}, (err, is_it_there)=>{
			if(err){
				console.log('Im STILL HERE MAHAHAHA');
			}
			else{
				console.log(is_it_there);
				console.log('WAIT!!!!! Noooooooo.....');
			}
		});
	}


}

module.exports = new TaskController();